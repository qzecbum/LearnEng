package com.prathik.learneng

data class Course(
    val title: String,
    val questions: List<String>,
    val options: List<List<String>>, // Notice the double List here
    val correctAnswers: List<Int>,
    val info: String
)

data class Word(
    val term: String,
    val definition: String,
    val example: String,
    val practiceQuestion: String,
    val practiceOptions: List<String>,
    val correctOptionIndex: Int
)

object CourseData {
    val words = listOf(
        Word(
            "Abandon",
            "To cease support or completely leave behind.",
            "They were forced to abandon the sinking ship.",
            "Which of the following is a synonym for abandon?",
            listOf("Keep", "Desert", "Cherish"),
            1
        ),
        Word(
            "Abate",
            "To become less intense or widespread.",
            "We waited for the storm to abate before driving.",
            "If a pain abates, it...",
            listOf("Worsens", "Decreases", "Spreads"),
            1
        ),
        Word(
            "Abdicate",
            "To renounce one's throne or fail to fulfill a responsibility.",
            "The king was forced to abdicate the throne.",
            "To abdicate a duty means to...",
            listOf("Fulfill it", "Give it up", "Assign it"),
            1
        ),
        Word(
            "Aberrant",
            "Departing from an accepted standard.",
            "His aberrant behavior caught the teacher's attention.",
            "An aberrant action is typically...",
            listOf("Normal", "Expected", "Unusual"),
            2
        ),
        Word(
            "Abet",
            "To encourage or assist someone to do something wrong, in particular, to commit a crime.",
            "He was charged with aiding and abetting the burglar.",
            "To abet someone is to...",
            listOf("Stop them", "Help them do wrong", "Praise them"),
            1
        ),
        Word(
            "Abhor",
            "To regard with disgust and hatred.",
            "I abhor violence in any form.",
            "If you abhor something, you...",
            listOf("Love it", "Hate it deeply", "Ignore it"),
            1
        ),
        Word(
            "Abject",
            "Extremely bad, unpleasant, and degrading.",
            "The family was living in abject poverty.",
            "Abject misery implies the situation is...",
            listOf("Mild", "Temporary", "Severe"),
            2
        ),
        Word(
            "Abominate",
            "To detest or loathe intensely.",
            "Many people abominate the taste of liver.",
            "Which word is a synonym for abominate?",
            listOf("Despise", "Adore", "Tolerate"),
            0
        ),
        Word(
            "Abortive",
            "Failing to produce the intended result.",
            "The rebels made an abortive attempt to overthrow the government.",
            "An abortive mission is one that...",
            listOf("Succeeds", "Fails", "Continues"),
            1
        ),
        Word(
            "Abscond",
            "To leave hurriedly and secretly, typically to avoid detection or arrest.",
            "The cashier decided to abscond with the day's profits.",
            "To abscond is to...",
            listOf("Flee secretly", "Arrive loudly", "Surrender"),
            0
        ),
        Word(
            "Absolve",
            "To set or declare someone free from blame, guilt, or responsibility.",
            "The pardon will absolve him of any crimes.",
            "If a judge absolves a defendant, the defendant is...",
            listOf("Guilty", "Cleared of blame", "Imprisoned"),
            1
        ),
        Word(
            "Abstruse",
            "Difficult to understand; obscure.",
            "The professor's lecture on quantum physics was too abstruse for the freshmen.",
            "An abstruse concept is...",
            listOf("Simple", "Hard to grasp", "Funny"),
            1
        ),
        Word(
            "Abysmal",
            "Extremely bad; appalling.",
            "The food at that restaurant was abysmal.",
            "Abysmal performance means the performance was...",
            listOf("Excellent", "Average", "Terrible"),
            2
        ),
        Word(
            "Acclimate",
            "To become accustomed to a new climate or to new conditions.",
            "It takes a few days to acclimate to the high altitude.",
            "When you acclimate, you...",
            listOf("Adjust", "Complain", "Leave"),
            0
        ),
        Word(
            "Accost",
            "To approach and address someone boldly or aggressively.",
            "Reporters accosted the mayor as he left the building.",
            "To accost someone is to...",
            listOf("Greet them shyly", "Confront them boldly", "Ignore them"),
            1
        ),
        Word(
            "Accrue",
            "To be received by someone in regular or increasing amounts over time.",
            "Interest will accrue on the loan until it is paid off.",
            "When benefits accrue, they...",
            listOf("Decrease", "Vanish", "Accumulate"),
            2
        ),
        Word(
            "Acquiesce",
            "To accept something reluctantly but without protest.",
            "Sara eventually had to acquiesce to her manager's demands.",
            "To acquiesce means to...",
            listOf("Argue", "Agree silently", "Fight back"),
            1
        ),
        Word(
            "Acrid",
            "Having an irritatingly strong and unpleasant taste or smell.",
            "The acrid smoke from the fire burned my eyes.",
            "An acrid smell is usually...",
            listOf("Sweet", "Pungent", "Odorless"),
            1
        ),
        Word(
            "Acuity",
            "Sharpness or keenness of thought, vision, or hearing.",
            "Owls possess excellent visual acuity for hunting at night.",
            "Mental acuity refers to...",
            listOf("Sharp intelligence", "Confusion", "Forgetfulness"),
            0
        ),
        Word(
            "Addendum",
            "An item of additional material, typically omissions, added at the end of a book or document.",
            "The author included an addendum to update the statistics.",
            "An addendum is found...",
            listOf("At the beginning", "At the end", "In the middle"),
            1
        ),
        Word(
            "Adjudicate",
            "To make a formal judgment or decision about a problem or disputed matter.",
            "The committee will adjudicate the claims made by both parties.",
            "To adjudicate is to act as a...",
            listOf("Judge", "Lawyer", "Witness"),
            0
        ),
        Word(
            "Adulation",
            "Obsequious flattery; excessive admiration or praise.",
            "The pop star grew tired of the constant adulation from her fans.",
            "Adulation involves...",
            listOf("Constructive criticism", "Excessive praise", "Indifference"),
            1
        ),
        Word(
            "Affable",
            "Friendly, good-natured, or easy to talk to.",
            "Her grandfather was an affable man who loved telling stories.",
            "An affable person is...",
            listOf("Hostile", "Approachable", "Silent"),
            1
        ),
        Word(
            "Agnostic",
            "A person who believes that nothing is known or can be known of the existence or nature of God.",
            "Though raised in a religious household, he later identified as agnostic.",
            "An agnostic is someone who is...",
            listOf("Certain of a deity", "Uncertain of a deity", "Against all religions"),
            1
        ),
        Word(
            "Agrarian",
            "Relating to cultivated land or the cultivation of land.",
            "The country's economy is largely agrarian.",
            "An agrarian society focuses on...",
            listOf("Technology", "Farming", "Mining"),
            1
        ),
        Word(
            "Alienate",
            "To cause someone to feel isolated or estranged.",
            "His bossy attitude managed to alienate all of his coworkers.",
            "To alienate people is to...",
            listOf("Bring them together", "Push them away", "Entertain them"),
            1
        ),
        Word(
            "Allay",
            "To diminish or put at rest (fear, suspicion, or worry).",
            "The report attempted to allay fears regarding the new policy.",
            "To allay concerns means to...",
            listOf("Calm them", "Increase them", "Ignore them"),
            0
        ),
        Word(
            "Allude",
            "To suggest or call attention to indirectly; hint at.",
            "She didn't mention him by name, but she did allude to his mistake.",
            "When you allude to something, you...",
            listOf("State it directly", "Hint at it", "Deny it completely"),
            1
        ),
        Word(
            "Altruistic",
            "Showing a disinterested and selfless concern for the well-being of others.",
            "Her altruistic nature led her to volunteer at the shelter every weekend.",
            "An altruistic act is driven by...",
            listOf("Selfishness", "Greed", "Selflessness"),
            2
        ),
        Word(
            "Amalgamate",
            "To combine or unite to form one organization or structure.",
            "The two companies will amalgamate to form a giant corporation.",
            "To amalgamate means to...",
            listOf("Separate", "Merge", "Destroy"),
            1
        ),
        Word(
            "Amatory",
            "Relating to or induced by sexual love or desire.",
            "He wrote her an amatory poem for Valentine's Day.",
            "Amatory writings focus on...",
            listOf("Warfare", "Romance", "Business"),
            1
        ),
        Word(
            "Ambient",
            "Relating to the immediate surroundings of something.",
            "The ambient lighting in the restaurant made it very romantic.",
            "Ambient sound refers to...",
            listOf("Loud music", "Background noise", "Absolute silence"),
            1
        ),
        Word(
            "Ambivalent",
            "Having mixed feelings or contradictory ideas about something or someone.",
            "She remained ambivalent about taking the new job.",
            "If you are ambivalent, you are...",
            listOf("Undecided", "Certain", "Furious"),
            0
        ),
        Word(
            "Ambulatory",
            "Relating to or adapted for walking.",
            "Once the patient was ambulatory, he was discharged from the hospital.",
            "An ambulatory patient can...",
            listOf("Walk", "See clearly", "Eat solids"),
            0
        ),
        Word(
            "Amity",
            "A friendly relationship.",
            "The two nations have lived in amity for decades.",
            "Amity between groups indicates...",
            listOf("Hostility", "Friendship", "War"),
            1
        ),
        Word(
            "Anachronism",
            "A thing belonging or appropriate to a period other than that in which it exists.",
            "The sword in the modern warfare movie was a glaring anachronism.",
            "An anachronism is something that is...",
            listOf("Out of place in time", "Very old", "Highly futuristic"),
            0
        ),
        Word(
            "Analogous",
            "Comparable in certain respects, typically in a way which makes clearer the nature of the things compared.",
            "The brain is often considered analogous to a computer.",
            "Things that are analogous are...",
            listOf("Completely different", "Somewhat similar", "Exactly identical"),
            1
        ),
        Word(
            "Ancillary",
            "Providing necessary support to the primary activities or operation of an organization, institution, or industry.",
            "The main factory relies on several ancillary facilities.",
            "An ancillary role is...",
            listOf("Primary", "Supporting", "Useless"),
            1
        ),
        Word(
            "Anomaly",
            "Something that deviates from what is standard, normal, or expected.",
            "The sudden drop in temperature was considered an anomaly.",
            "An anomaly is an...",
            listOf("Irregularity", "Expectation", "Standard"),
            0
        ),
        Word(
            "Apparition",
            "A ghost or ghostlike image of a person.",
            "She claimed she saw a ghostly apparition in the hallway.",
            "An apparition is a...",
            listOf("Solid object", "Phantom", "Animal"),
            1
        ),
        Word(
            "Approbation",
            "Approval or praise.",
            "The opera met with high approbation from the critics.",
            "To receive approbation is to receive...",
            listOf("Praise", "Criticism", "Money"),
            0
        ),
        Word(
            "Arcane",
            "Understood by few; mysterious or secret.",
            "The professor specialized in arcane medieval literature.",
            "Arcane knowledge is...",
            listOf("Common", "Mysterious", "Useless"),
            1
        ),
        Word(
            "Archetype",
            "A very typical example of a certain person or thing.",
            "He is the archetype of a successful entrepreneur.",
            "An archetype serves as a...",
            listOf("Mistake", "Model", "Warning"),
            1
        ),
        Word(
            "Archipelago",
            "A group of islands.",
            "Hawaii is an archipelago located in the Pacific Ocean.",
            "An archipelago is made up of...",
            listOf("Mountains", "Deserts", "Islands"),
            2
        ),
        Word(
            "Arduous",
            "Involving or requiring strenuous effort; difficult and tiring.",
            "Climbing Mount Everest is an extremely arduous task.",
            "An arduous journey is...",
            listOf("Easy", "Difficult", "Quick"),
            1
        ),
        Word(
            "Assay",
            "The testing of a metal or ore to determine its ingredients and quality.",
            "The jeweler performed an assay to determine the purity of the gold.",
            "To assay something is to...",
            listOf("Sell it", "Analyze it", "Hide it"),
            1
        ),
        Word(
            "Attrition",
            "The action or process of gradually reducing the strength or effectiveness of someone or something through sustained attack or pressure.",
            "The military campaign became a war of attrition.",
            "Attrition involves wearing something down...",
            listOf("Gradually", "Instantly", "Never"),
            0
        ),
        Word(
            "Auspices",
            "Under the direction or teaching of; patronage.",
            "The project was organized under the auspices of the local charity.",
            "Working under someone's auspices means working under their...",
            listOf("Threat", "Sponsorship", "Ignorance"),
            1
        ),
        Word(
            "Autocratic",
            "Relating to a ruler who has absolute power.",
            "The CEO's autocratic management style drove away talented employees.",
            "An autocratic leader acts like a...",
            listOf("Dictator", "Servant", "Peer"),
            0
        ),
        Word(
            "Awry",
            "Away from the appropriate, planned, or expected course; amiss.",
            "Despite careful planning, everything went awry.",
            "If plans go awry, they go...",
            listOf("Perfectly", "Wrong", "Slowly"),
            1
        ),
        Word(
            "Axiom",
            "A statement or proposition which is regarded as being established, accepted, or self-evidently true.",
            "It is a widely held axiom that governments should not negotiate with terrorists.",
            "An axiom is generally considered to be...",
            listOf("False", "True", "Debatable"),
            1
        ),
        Word(
            "Baroque",
            "Highly ornate and extravagant in style.",
            "The church featured beautiful baroque architecture.",
            "A baroque style is characterized by...",
            listOf("Simplicity", "Extravagance", "Modernity"),
            1
        ),
        Word(
            "Bastion",
            "An institution, place, or person strongly defending or upholding particular principles, attitudes, or activities.",
            "The university is seen as a bastion of academic freedom.",
            "A bastion acts as a...",
            listOf("Defender", "Attacker", "Bystander"),
            0
        ),
        Word(
            "Bedeck",
            "To decorate.",
            "They decided to bedeck the hall with flowers for the wedding.",
            "To bedeck means to...",
            listOf("Destroy", "Decorate", "Clean"),
            1
        ),
        Word(
            "Bedevil",
            "To cause great and continual trouble to.",
            "Technical issues continued to bedevil the project.",
            "To bedevil someone is to...",
            listOf("Help them", "Torment them", "Ignore them"),
            1
        ),
        Word(
            "Bedlam",
            "A scene of uproar and confusion.",
            "It was absolute bedlam in the store on Black Friday.",
            "Bedlam implies a state of...",
            listOf("Peace", "Chaos", "Order"),
            1
        ),
        Word(
            "Beget",
            "To bring (a child) into existence by the process of reproduction; give rise to; bring about.",
            "Violence often begets more violence.",
            "To beget something means to...",
            listOf("Destroy it", "Cause it", "Hide it"),
            1
        ),
        Word(
            "Beguile",
            "Charm or enchant (someone), sometimes in a deceptive way.",
            "He used his charm to beguile the wealthy widow out of her money.",
            "To beguile someone is to...",
            listOf("Bore them", "Charm them", "Insult them"),
            1
        ),
        Word(
            "Behest",
            "A person's orders or command.",
            "He attended the meeting at the behest of his manager.",
            "If you do something at someone's behest, you do it because of their...",
            listOf("Request", "Mistake", "Absence"),
            0
        ),
        Word(
            "Beholden",
            "Owing thanks or having a duty to someone in return for help or a service.",
            "I don't like being beholden to anyone for money.",
            "Being beholden means you feel...",
            listOf("Independent", "Indebted", "Angry"),
            1
        )
    )

    val courses = listOf(
        Course(
            title = "Diplomatic Disagreement",
            questions = listOf("With all due ___, I must disagree.", "I see it from a slightly ___ perspective.", "We are looking through a flawed ___.", "I'm not entirely ___ by that argument."),
            options = listOf(
                listOf("respect", "regard", "care", "notice"),
                listOf("different", "other", "new", "odd"),
                listOf("lens", "glass", "eye", "view"),
                listOf("convinced", "sold", "bought", "taken")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Diplomatic Disagreement**: Disagree without offending. Essential for boardrooms."
        ),
        Course(
            title = "Softening Bad News",
            questions = listOf("Unfortunately, there has been a slight ___.", "I'm afraid we've hit a bit of a ___.", "Things didn't go exactly as ___.", "We may need to ___ our expectations."),
            options = listOf(
                listOf("complication", "issue", "problem", "thing"),
                listOf("roadblock", "wall", "stop", "bump"),
                listOf("planned", "thought", "hoped", "wished"),
                listOf("recalibrate", "change", "move", "drop")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Softening Bad News**: Deliver negative updates gently using mitigators."
        ),
        Course(
            title = "Advanced Negotiation",
            questions = listOf("Is there any ___ room here?", "I was hoping for a more ___ offer.", "We need to find common ___.", "Let's aim for a mutually ___ outcome."),
            options = listOf(
                listOf("wiggle", "move", "extra", "breathing"),
                listOf("lucrative", "rich", "high", "big"),
                listOf("ground", "space", "area", "thought"),
                listOf("beneficial", "good", "nice", "fair")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Advanced Negotiation**: Move past basic haggling to find strategic compromises."
        ),
        Course(
            title = "Pitching a Vision",
            questions = listOf("Imagine a world where this is ___.", "This idea represents a paradigm ___.", "Our core ___ is to disrupt the market.", "This will effectively ___ the industry."),
            options = listOf(
                listOf("ubiquitous", "everywhere", "common", "known"),
                listOf("shift", "change", "move", "jump"),
                listOf("objective", "goal", "plan", "idea"),
                listOf("disrupt", "break", "change", "move")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Pitching a Vision**: Use compelling verbs to sell an innovative idea."
        ),
        Course(
            title = "Expressing Skepticism",
            questions = listOf("I have serious ___ about this.", "That sounds slightly ___ to me.", "I'm finding that hard to ___.", "Let's play devil's ___ for a moment."),
            options = listOf(
                listOf("reservations", "doubts", "thoughts", "worries"),
                listOf("far-fetched", "crazy", "weird", "odd"),
                listOf("swallow", "eat", "take", "drink"),
                listOf("advocate", "lawyer", "person", "friend")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Expressing Skepticism**: Doubt a claim intellectually rather than aggressively."
        ),
        Course(
            title = "Steering Conversations",
            questions = listOf("Let's circle ___ to the main point.", "I'd like to ___ the conversation towards budget.", "Getting back on ___, what is the goal?", "If I could just ___ us back to the agenda."),
            options = listOf(
                listOf("back", "round", "over", "up"),
                listOf("pivot", "turn", "move", "push"),
                listOf("track", "path", "road", "way"),
                listOf("steer", "drive", "move", "push")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Steering Conversations**: Pivot an off-topic discussion back to the agenda."
        ),
        Course(
            title = "Handling Interruptions",
            questions = listOf("Please let me ___ my thought.", "If I may just ___ my sentence.", "Hold that ___, I wasn't quite done.", "I'd like to complete my ___."),
            options = listOf(
                listOf("finish", "end", "close", "stop"),
                listOf("conclude", "finish", "stop", "end"),
                listOf("thought", "idea", "point", "word"),
                listOf("point", "word", "speech", "talk")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Handling Interruptions**: Assert your right to finish speaking professionally."
        ),
        Course(
            title = "Deflecting Questions",
            questions = listOf("I'm not at ___ to discuss that.", "That's a rather ___ question.", "I'd prefer not to ___ on that topic.", "Let's keep this strictly ___."),
            options = listOf(
                listOf("liberty", "freedom", "right", "choice"),
                listOf("loaded", "heavy", "big", "bad"),
                listOf("elaborate", "talk", "speak", "expand"),
                listOf("confidential", "secret", "quiet", "hidden")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Deflecting Questions**: Dodge invasive queries without appearing evasive."
        ),
        Course(
            title = "Constructive Criticism",
            questions = listOf("There's some room for ___ here.", "You might want to ___ your approach.", "It's good, but it needs some ___.", "Let's work on ___ this process."),
            options = listOf(
                listOf("improvement", "better", "growth", "up"),
                listOf("refine", "change", "fix", "clean"),
                listOf("polishing", "cleaning", "fixing", "buffing"),
                listOf("streamlining", "speeding", "making", "doing")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Constructive Criticism**: Critique the work, not the person."
        ),
        Course(
            title = "Receiving Feedback",
            questions = listOf("I appreciate the candid ___.", "I take your points on ___.", "I'll certainly ___ that in mind.", "Thank you for the constructive ___."),
            options = listOf(
                listOf("feedback", "words", "talk", "thoughts"),
                listOf("board", "mind", "table", "top"),
                listOf("bear", "keep", "hold", "have"),
                listOf("criticism", "words", "notes", "hate")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Receiving Feedback**: Accept notes gracefully without becoming defensive."
        ),
        Course(
            title = "Breaking the Ice",
            questions = listOf("What brings you to this ___?", "I couldn't help but ___ your tie.", "Have you been to one of these ___ before?", "It's a fantastic ___, isn't it?"),
            options = listOf(
                listOf("event", "party", "thing", "place"),
                listOf("admire", "look", "see", "stare"),
                listOf("mixers", "parties", "things", "events"),
                listOf("turnout", "crowd", "group", "pack")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Breaking the Ice**: Start high-level networking conversations naturally."
        ),
        Course(
            title = "Exiting Conversations",
            questions = listOf("If you'll ___ me, I must mingle.", "It's been a pleasure ___ with you.", "I need to refresh my ___.", "I won't take up any more of your ___."),
            options = listOf(
                listOf("excuse", "let", "leave", "drop"),
                listOf("speaking", "talking", "chatting", "word"),
                listOf("drink", "glass", "cup", "water"),
                listOf("time", "space", "day", "life")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Exiting Conversations**: Leave a chat seamlessly without awkwardness."
        ),
        Course(
            title = "Advocating for Others",
            questions = listOf("I'd like to ___ for Sarah's work.", "He has been absolutely ___ to this team.", "Her contributions were purely ___.", "I highly ___ him for this role."),
            options = listOf(
                listOf("vouch", "speak", "talk", "stand"),
                listOf("integral", "core", "main", "key"),
                listOf("stellar", "good", "bright", "nice"),
                listOf("recommend", "suggest", "tell", "push")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Advocating for Others**: Endorse peers using powerful corporate adjectives."
        ),
        Course(
            title = "Apologizing for Errors",
            questions = listOf("I take full ___ for this oversight.", "That was a severe ___ of judgment.", "I sincerely ___ for the inconvenience.", "We are working to ___ the situation."),
            options = listOf(
                listOf("responsibility", "blame", "weight", "load"),
                listOf("lapse", "gap", "break", "fall"),
                listOf("apologize", "sorry", "regret", "beg"),
                listOf("rectify", "fix", "clear", "clean")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Apologizing for Errors**: Take ownership of critical mistakes cleanly."
        ),
        Course(
            title = "Sarcasm Nuances",
            questions = listOf("Oh, that's just absolutely ___.", "Could you be any more ___?", "I am positively ___ with joy.", "That was a truly ___ observation."),
            options = listOf(
                listOf("thrilling", "fun", "great", "good"),
                listOf("obvious", "clear", "plain", "open"),
                listOf("overwhelmed", "full", "big", "much"),
                listOf("astute", "smart", "sharp", "good")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Sarcasm Nuances**: Master the dry delivery of English sarcasm."
        ),
        Course(
            title = "Using Irony",
            questions = listOf("Ironically, it had the ___ effect.", "It's a classic case of ___ irony.", "The irony is completely ___ on him.", "It's somewhat ___ that we failed."),
            options = listOf(
                listOf("opposite", "other", "strange", "weird"),
                listOf("dramatic", "big", "huge", "sad"),
                listOf("lost", "gone", "missing", "hidden"),
                listOf("amusing", "funny", "silly", "sad")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Using Irony**: Highlight contradictions for conversational effect."
        ),
        Course(
            title = "Hyperbole",
            questions = listOf("I've told you a ___ times.", "This bag weighs a literal ___.", "I am absolutely ___ right now.", "It took an ___ to finish."),
            options = listOf(
                listOf("million", "ten", "five", "lots"),
                listOf("ton", "pound", "rock", "stone"),
                listOf("starving", "hungry", "empty", "dead"),
                listOf("eternity", "hour", "week", "year")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Hyperbole**: Exaggerate wildly for comedic or dramatic emphasis."
        ),
        Course(
            title = "Understatement",
            questions = listOf("It's not exactly a walk in the ___.", "We have a ___ issue to resolve.", "It was a somewhat ___ experience.", "I'm a little ___ by the news."),
            options = listOf(
                listOf("park", "street", "road", "grass"),
                listOf("minor", "small", "tiny", "big"),
                listOf("challenging", "hard", "tough", "bad"),
                listOf("troubled", "hurt", "sad", "mad")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Understatement**: Downplay a major situation for classic British-style humor."
        ),
        Course(
            title = "Abstract Concepts",
            questions = listOf("The concept is largely ___.", "It's hard to grasp the ___ nature of it.", "Let's examine the underlying ___.", "It exists purely in ___."),
            options = listOf(
                listOf("theoretical", "fake", "false", "true"),
                listOf("ephemeral", "fleeting", "fast", "gone"),
                listOf("premise", "base", "ground", "start"),
                listOf("theory", "mind", "thought", "brain")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Abstract Concepts**: Discuss theories rather than tangible objects."
        ),
        Course(
            title = "Philosophical Debates",
            questions = listOf("That poses a moral ___.", "It's a matter of subjective ___.", "Let's explore the ethical ___.", "This challenges traditional ___."),
            options = listOf(
                listOf("dilemma", "problem", "trap", "box"),
                listOf("morality", "rules", "laws", "truths"),
                listOf("implications", "thoughts", "ideas", "ends"),
                listOf("dogma", "rules", "beliefs", "ways")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Philosophical Debates**: Argue ethics and morality at a high level."
        ),
        Course(
            title = "Analyzing Art",
            questions = listOf("The artist uses a fascinating ___.", "Notice the juxtaposition of ___.", "It evokes a sense of deep ___.", "The brushwork is quite ___."),
            options = listOf(
                listOf("medium", "paint", "tool", "way"),
                listOf("shadows", "lights", "colors", "forms"),
                listOf("melancholy", "sadness", "dark", "hurt"),
                listOf("evocative", "deep", "smart", "strong")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Analyzing Art**: Critique aesthetics, lighting, and artistic intent."
        ),
        Course(
            title = "Niche Hobbies",
            questions = listOf("I've recently taken up ___.", "It requires a lot of meticulous ___.", "The community is very ___.", "It's a highly specialized ___."),
            options = listOf(
                listOf("calligraphy", "writing", "pens", "art"),
                listOf("precision", "care", "time", "work"),
                listOf("tight-knit", "close", "small", "good"),
                listOf("niche", "small", "tiny", "corner")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Niche Hobbies**: Speak passionately about specialized personal interests."
        ),
        Course(
            title = "Technical Explanations",
            questions = listOf("Let me break down the ___.", "The system utilizes advanced ___.", "It operates on a closed ___.", "The algorithm is highly ___."),
            options = listOf(
                listOf("architecture", "build", "bones", "shape"),
                listOf("heuristics", "rules", "math", "logic"),
                listOf("loop", "circle", "ring", "track"),
                listOf("optimized", "fast", "good", "clean")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Technical Explanations**: Break down complex systems for laymen."
        ),
        Course(
            title = "Setting the Scene",
            questions = listOf("The atmosphere was incredibly ___.", "It was a bleak, desolate ___.", "The air was thick with ___.", "The surroundings were purely ___."),
            options = listOf(
                listOf("oppressive", "heavy", "hard", "dark"),
                listOf("landscape", "land", "ground", "view"),
                listOf("anticipation", "wait", "hope", "fear"),
                listOf("idyllic", "nice", "calm", "sweet")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Setting the Scene**: Paint a vivid picture using descriptive adjectives."
        ),
        Course(
            title = "Building Tension",
            questions = listOf("The suspense was almost ___.", "You could cut the tension with a ___.", "Everyone was on the edge of their ___.", "A sense of dread slowly ___."),
            options = listOf(
                listOf("palpable", "real", "heavy", "thick"),
                listOf("knife", "sword", "blade", "hand"),
                listOf("seats", "chairs", "beds", "toes"),
                listOf("crept", "walked", "ran", "moved")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Building Tension**: Pace your storytelling to keep listeners hooked."
        ),
        Course(
            title = "Delivering Punchlines",
            questions = listOf("And then, out of ___, he fell.", "The timing of the joke was ___.", "It all came down to the final ___.", "The punchline completely ___ me."),
            options = listOf(
                listOf("nowhere", "space", "air", "dark"),
                listOf("impeccable", "perfect", "exact", "good"),
                listOf("wire", "line", "end", "finish"),
                listOf("slayed", "killed", "hit", "broke")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Delivering Punchlines**: Master the timing of a conversational joke."
        ),
        Course(
            title = "Consoling Friends",
            questions = listOf("I am so incredibly sorry for your ___.", "Please accept my deepest ___.", "I'm here for you, no matter ___.", "Words cannot express my ___."),
            options = listOf(
                listOf("loss", "pain", "hurt", "sadness"),
                listOf("condolences", "sorrys", "regrets", "tears"),
                listOf("what", "how", "who", "when"),
                listOf("sympathy", "care", "love", "heart")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Consoling Friends**: Offer profound empathy during times of deep grief."
        ),
        Course(
            title = "Celebrating Milestones",
            questions = listOf("Let's raise a ___ to your success.", "This is a monumental ___.", "You've truly earned this ___.", "Here's to your continued ___."),
            options = listOf(
                listOf("toast", "glass", "cup", "cheer"),
                listOf("achievement", "win", "goal", "prize"),
                listOf("accolade", "prize", "award", "gift"),
                listOf("prosperity", "wealth", "luck", "joy")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Celebrating Milestones**: Toast to major life achievements eloquently."
        ),
        Course(
            title = "Societal Trends",
            questions = listOf("There's a growing ___ towards remote work.", "We are seeing a cultural ___.", "This generation is highly ___.", "It's a prevalent societal ___."),
            options = listOf(
                listOf("backlash", "push", "hate", "force"),
                listOf("shift", "move", "change", "turn"),
                listOf("cynical", "sad", "dark", "bad"),
                listOf("norm", "rule", "way", "law")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Societal Trends**: Analyze shifts in modern culture and behavior."
        ),
        Course(
            title = "Office Politics",
            questions = listOf("Navigating the corporate ___ is tough.", "He's just playing office ___.", "There's a lot of red ___ here.", "You have to read between the ___."),
            options = listOf(
                listOf("labyrinth", "maze", "trap", "web"),
                listOf("politics", "games", "rules", "tricks"),
                listOf("tape", "string", "wire", "rope"),
                listOf("lines", "words", "spaces", "texts")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Office Politics**: Discuss the unspoken rules of corporate environments."
        ),
        Course(
            title = "Setting Boundaries",
            questions = listOf("I need to draw a hard ___ here.", "That crosses a professional ___.", "I cannot accommodate that ___.", "My schedule is currently at ___."),
            options = listOf(
                listOf("line", "boundary", "wall", "fence"),
                listOf("boundary", "line", "mark", "step"),
                listOf("request", "ask", "plea", "favor"),
                listOf("capacity", "full", "max", "end")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Setting Boundaries**: Firmly protect your personal and professional time."
        ),
        Course(
            title = "Refusing Politely",
            questions = listOf("I must respectfully ___.", "I'm flattered, but I cannot ___.", "I have to pass on this ___.", "That won't be feasible for ___."),
            options = listOf(
                listOf("decline", "refuse", "stop", "quit"),
                listOf("commit", "promise", "swear", "do"),
                listOf("opportunity", "chance", "job", "gig"),
                listOf("me", "you", "us", "them")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Refusing Politely**: Say no to major requests without burning bridges."
        ),
        Course(
            title = "Requesting Favors",
            questions = listOf("Could I ask a massive ___ of you?", "I'm in a bit of a ___.", "Would you be terribly ___ to help?", "I really need a huge ___."),
            options = listOf(
                listOf("favor", "help", "task", "job"),
                listOf("bind", "jam", "trap", "hole"),
                listOf("obliging", "nice", "kind", "sweet"),
                listOf("solid", "help", "block", "rock")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Requesting Favors**: Ask for significant help without sounding entitled."
        ),
        Course(
            title = "Deep Gratitude",
            questions = listOf("I cannot thank you ___.", "Your help was truly ___.", "I am forever in your ___.", "I owe you a massive ___."),
            options = listOf(
                listOf("enough", "more", "much", "all"),
                listOf("invaluable", "good", "great", "nice"),
                listOf("debt", "owed", "red", "bound"),
                listOf("favor", "help", "debt", "task")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Deep Gratitude**: Express profound thanks beyond a simple 'thank you'."
        ),
        Course(
            title = "Hypothesizing",
            questions = listOf("Suppose, hypothetically, we ___.", "What if we were to pivot ___?", "Assuming all goes according to ___.", "Let's entertain the ___ that it works."),
            options = listOf(
                listOf("failed", "broke", "lost", "stopped"),
                listOf("strategy", "plan", "way", "move"),
                listOf("plan", "design", "map", "thought"),
                listOf("notion", "idea", "thought", "whim")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Hypothesizing**: Explore theoretical scenarios using advanced conditionals."
        ),
        Course(
            title = "Regrets & Hindsight",
            questions = listOf("In hindsight, it was a poor ___.", "I deeply ___ that decision.", "If I could turn back the ___.", "Looking back, we should have ___."),
            options = listOf(
                listOf("call", "choice", "move", "pick"),
                listOf("regret", "hate", "rue", "mourn"),
                listOf("clock", "time", "dial", "watch"),
                listOf("known", "seen", "thought", "felt")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Regrets & Hindsight**: Reflect on past mistakes with mature vocabulary."
        ),
        Course(
            title = "Speculating Futures",
            questions = listOf("I predict a massive ___ in the market.", "The long-term outlook is ___.", "We are projecting significant ___.", "The future looks highly ___."),
            options = listOf(
                listOf("correction", "drop", "fall", "crash"),
                listOf("bullish", "good", "great", "green"),
                listOf("growth", "money", "gains", "heights"),
                listOf("promising", "bright", "shiny", "good")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Speculating Futures**: Predict industry or global outcomes confidently."
        ),
        Course(
            title = "Business Idioms",
            questions = listOf("Let's touch ___ next week.", "We need to think outside the ___.", "Let's run it up the ___.", "We need to move the ___."),
            options = listOf(
                listOf("base", "ground", "top", "end"),
                listOf("box", "square", "lines", "rules"),
                listOf("flagpole", "stick", "mast", "tree"),
                listOf("needle", "dial", "pin", "line")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Business Idioms**: Speak fluent corporate jargon."
        ),
        Course(
            title = "Success Phrasal Verbs",
            questions = listOf("We really knocked it out of the ___.", "She is definitely going ___.", "He pulled it off without a ___.", "They passed with flying ___."),
            options = listOf(
                listOf("park", "field", "court", "yard"),
                listOf("places", "far", "up", "away"),
                listOf("hitch", "snag", "break", "bump"),
                listOf("colors", "flags", "banners", "rags")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Success Phrasal Verbs**: Describe victories using natural idiomatic phrases."
        ),
        Course(
            title = "Persuasion Tactics",
            questions = listOf("I urge you to reconsider your ___.", "Think of the long-term ___.", "The benefits heavily outweigh the ___.", "I implore you to look at the ___."),
            options = listOf(
                listOf("stance", "pose", "step", "view"),
                listOf("ramifications", "effects", "things", "ends"),
                listOf("risks", "bads", "lows", "costs"),
                listOf("data", "facts", "stats", "numbers")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Persuasion Tactics**: Convince others using logical frameworks."
        ),
        Course(
            title = "De-escalation",
            questions = listOf("Let's all take a step ___.", "There's no need to raise our ___.", "Let's approach this logically, not ___.", "We need to diffuse the ___."),
            options = listOf(
                listOf("back", "away", "down", "out"),
                listOf("voices", "tones", "volumes", "hands"),
                listOf("emotionally", "madly", "sadly", "hotly"),
                listOf("situation", "bomb", "anger", "fire")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**De-escalation**: Calm a heated argument with measured tones."
        ),
        Course(
            title = "Conflict Mediation",
            questions = listOf("Let's hear both sides of the ___.", "We need an impartial ___.", "Let's find a workable ___.", "We must resolve this amicably and ___."),
            options = listOf(
                listOf("argument", "fight", "spat", "clash"),
                listOf("mediator", "judge", "guy", "friend"),
                listOf("compromise", "deal", "pact", "truce"),
                listOf("fairly", "nicely", "good", "well")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Conflict Mediation**: Act as a neutral third party in disputes."
        ),
        Course(
            title = "Expressing Indifference",
            questions = listOf("I couldn't care ___.", "It makes no difference to ___.", "I am completely ___ to it.", "Whatever happens, happens ___."),
            options = listOf(
                listOf("less", "more", "at", "in"),
                listOf("me", "you", "us", "them"),
                listOf("indifferent", "cold", "dead", "blind"),
                listOf("regardless", "anyway", "still", "so")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Expressing Indifference**: Show a complete lack of concern politely."
        ),
        Course(
            title = "Empathy vs Pity",
            questions = listOf("I can only imagine how hard that ___.", "I truly empathize with your ___.", "Your feelings are completely ___.", "I stand with you in this ___."),
            options = listOf(
                listOf("is", "was", "be", "been"),
                listOf("plight", "pain", "hurt", "sorrow"),
                listOf("valid", "real", "true", "sound"),
                listOf("solidarity", "union", "force", "strength")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Empathy vs Pity**: Support someone without making them feel small."
        ),
        Course(
            title = "Complaining Upwards",
            questions = listOf("I have a grievance to ___.", "The current workflow is simply ___.", "I need to escalate this ___.", "This is severely impacting our ___."),
            options = listOf(
                listOf("air", "vent", "state", "say"),
                listOf("untenable", "bad", "awful", "hard"),
                listOf("matter", "thing", "issue", "problem"),
                listOf("productivity", "work", "speed", "output")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Complaining Upwards**: Raise serious structural issues to management."
        ),
        Course(
            title = "Commending Excellence",
            questions = listOf("Your performance has been absolutely ___.", "You truly went above and ___.", "Your dedication is highly ___.", "You are a vital ___ to this team."),
            options = listOf(
                listOf("flawless", "perfect", "great", "nice"),
                listOf("beyond", "over", "up", "out"),
                listOf("commendable", "good", "nice", "sweet"),
                listOf("asset", "piece", "part", "tool")
            ),
            correctAnswers = listOf(0, 0, 0, 0),
            info = "**Commending Excellence**: Praise outstanding work with high-tier vocabulary."
        )
    )
}
