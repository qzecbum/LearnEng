package com.prathik.learneng.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = Green80,
    secondary = GreenGrey80,
    tertiary = LightGreen80,
    background = DarkGreenBackground,
    surface = DarkGreenSurface,
    surfaceVariant = DarkGreenSurfaceVariant,
    primaryContainer = Green40,
    secondaryContainer = GreenGrey40,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onTertiary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    onPrimaryContainer = Color.White,
    onSecondaryContainer = Color.White,
    outline = GreenGrey80
)

private val LightColorScheme = lightColorScheme(
    primary = Green40,
    secondary = GreenGrey40,
    tertiary = LightGreen40,
    background = LightGreenBackground,
    surface = LightGreenSurface,
    surfaceVariant = LightGreenSurfaceVariant,
    primaryContainer = LightGreen80,
    secondaryContainer = LightGreenSurfaceVariant,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF1C1B1F),
    onSurface = Color(0xFF1C1B1F),
    onPrimaryContainer = Color(0xFF002100),
    onSecondaryContainer = Color(0xFF0B2000),
    outline = GreenGrey40
)

@Composable
fun LearnEngTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}