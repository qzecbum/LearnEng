package com.prathik.learneng

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Abc
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.KeyboardDoubleArrowLeft
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.CircleShape
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.firebase.Firebase
import com.google.firebase.database.database
import com.prathik.learneng.ui.theme.LearnEngTheme
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

// DataStore and State Keys
val Context.dataStore by preferencesDataStore(name = "data")
val PhrasesCompleteKEY = intPreferencesKey("PhrasesComplete")
val ThemeModeKEY = intPreferencesKey("ThemeMode") // 0: System, 1: Light, 2: Dark
val LearnedWordsKEY = stringSetPreferencesKey("LearnedWords")

// Global Navigation State
var selectedItem by mutableIntStateOf(1)
var CurrPhrase by mutableIntStateOf(0)
var CurrLesson by mutableIntStateOf(0) // 0: Selection, 1: Quiz/Lesson, 2: Infinite Practice
var currQuestionIndex by mutableIntStateOf(0)
var userAnswers by mutableStateOf(mapOf<Int, Int>())
var quizFinished by mutableStateOf(false)

var practiceCorrectCount by mutableIntStateOf(0)
var practiceTotalCount by mutableIntStateOf(0)
var isPracticeFinished by mutableStateOf(false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeMode by remember { dataStore.data.map { it[ThemeModeKEY] ?: 0 } }.collectAsState(initial = 0)
            val darkTheme = when (themeMode) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            LearnEngTheme(darkTheme = darkTheme) {
                DrawMain()
            }
        }
    }
}

@Composable
fun Modifier.bouncy(interactionSource: MutableInteractionSource) = composed {
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "bouncyScale"
    )
    this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

@Composable
fun Modifier.bouncyClickable(enabled: Boolean = true, onClick: () -> Unit) = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "bouncyScale"
    )

    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = interactionSource,
            indication = null,
            enabled = enabled,
            onClick = onClick
        )
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun DrawMain() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    val courses = CourseData.courses
    val learnedWordsState = remember { context.dataStore.data.map { it[LearnedWordsKEY] ?: emptySet() } }.collectAsState(initial = emptySet())
    val learnedWords = learnedWordsState.value

    val coursesFinishedCountState = remember {
        context.dataStore.data.map { preferences ->
            preferences[PhrasesCompleteKEY] ?: 0
        }
    }.collectAsState(initial = 0)
    val coursesFinishedCount = coursesFinishedCountState.value

    val scoresState = courses.indices.map { i ->
        context.dataStore.data.map { preferences ->
            preferences[intPreferencesKey("score_$i")] ?: -1
        }.collectAsState(initial = -1)
    }

    var showNewWordDialog by remember { mutableStateOf<Word?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    AnimatedContent(
                        targetState = if (CurrLesson == 0) {
                            if (selectedItem == 1) "LearnEng - Courses" else if (selectedItem == 2) "LearnEng - Vocabulary" else "LearnEng - Settings"
                        } else if (CurrLesson == 2) {
                            "Practice Vocabulary"
                        } else {
                            if (selectedItem == 1) {
                                courses.getOrNull(CurrPhrase)?.title ?: "Course"
                            } else {
                                CourseData.words.getOrNull(CurrPhrase)?.term ?: "Word"
                            }
                        },
                        transitionSpec = {
                            (fadeIn() + scaleIn(initialScale = 0.8f))
                                .togetherWith(fadeOut() + scaleOut(targetScale = 0.8f))
                        },
                        label = "TitleAnimation"
                    ) { targetTitle ->
                        Text(targetTitle)
                    }
                },
                actions = {
                    AnimatedVisibility(visible = CurrLesson == 0 && selectedItem != 3) {
                        val settingsInteraction = remember { MutableInteractionSource() }
                        IconButton(
                            onClick = { selectedItem = 3 },
                            interactionSource = settingsInteraction,
                            modifier = Modifier.bouncy(settingsInteraction)
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                        }
                    }
                    if (CurrLesson == 2 && !isPracticeFinished) {
                        val endInteraction = remember { MutableInteractionSource() }
                        TextButton(
                            onClick = { isPracticeFinished = true },
                            interactionSource = endInteraction,
                            modifier = Modifier.bouncy(endInteraction)
                        ) {
                            Text("End", color = Color.Red, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (CurrLesson == 1 || (CurrLesson == 2 && isPracticeFinished)) {
                        val backInteraction = remember { MutableInteractionSource() }
                        IconButton(
                            onClick = { 
                                CurrLesson = 0 
                                isPracticeFinished = false
                            },
                            interactionSource = backInteraction,
                            modifier = Modifier.bouncy(backInteraction)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.KeyboardDoubleArrowLeft,
                                contentDescription = "Back"
                            )
                        }
                    }
                },
            )
        },
        bottomBar = {
            if (CurrLesson == 0) {
                Surface(
                    modifier = Modifier
                        .padding(horizontal = 48.dp)
                        .padding(bottom = 32.dp)
                        .navigationBarsPadding()
                        .fillMaxWidth()
                        .height(64.dp),
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f),
                    tonalElevation = 0.dp,
                    shadowElevation = 0.dp
                ) {
                    NavigationBar(
                        containerColor = Color.Transparent,
                        tonalElevation = 0.dp
                    ) {
                        NavigationBarItem(
                            selected = selectedItem == 1,
                            onClick = { selectedItem = 1 },
                            icon = { Icon(Icons.Default.AutoStories, null) },
                            label = { Text("Phrases") }
                        )

                        NavigationBarItem(
                            selected = selectedItem == 2,
                            onClick = { selectedItem = 2 },
                            icon = { Icon(Icons.Default.Abc, null) },
                            label = { Text("Words") }
                        )

                        NavigationBarItem(
                            selected = selectedItem == 3,
                            onClick = { selectedItem = 3 },
                            icon = { Icon(Icons.Default.Settings, null) },
                            label = { Text("Settings") }
                        )
                    }
                }
            }
        }
    ) { contentPadding ->
        AnimatedContent(
            targetState = selectedItem to CurrLesson,
            transitionSpec = {
                if (targetState.second > initialState.second || targetState.first > initialState.first) {
                    (slideInHorizontally { it } + fadeIn())
                        .togetherWith(slideOutHorizontally { -it / 2 } + fadeOut())
                } else {
                    (slideInHorizontally { -it } + fadeIn())
                        .togetherWith(slideOutHorizontally { it / 2 } + fadeOut())
                }.using(
                    SizeTransform(clip = false)
                )
            },
            label = "MainContentTransition"
        ) { (item, lesson) ->
            Column(modifier = Modifier.padding(contentPadding)) {
                if (item == 1 && lesson == 0) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        items(courses.size) { i ->
                            val score = scoresState[i].value
                            val isVisible = i <= coursesFinishedCount
                            
                            if (isVisible) {
                                val cardColor = when {
                                    score == 4 -> Color.Green.copy(alpha = 0.1f)
                                    score >= 2 -> Color.Yellow.copy(alpha = 0.1f)
                                    score >= 0 -> Color.Red.copy(alpha = 0.1f)
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                }
                                
                                Card(
                                    modifier = Modifier
                                        .padding(10.dp)
                                        .fillMaxWidth()
                                        .bouncyClickable {
                                            val database = Firebase.database.reference
                                            database.child("PhraseClick").setValue(courses[i].title)
                                            CurrPhrase = i
                                            CurrLesson = 1
                                            currQuestionIndex = 0
                                            userAnswers = emptyMap()
                                            quizFinished = false
                                        },
                                    colors = CardDefaults.cardColors(containerColor = cardColor)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(20.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = courses[i].title)
                                        if (score >= 0) {
                                            Text(
                                                text = "Score: $score/4",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (item == 2 && lesson == 0) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        val practiceInteraction = remember { MutableInteractionSource() }
                        Button(
                            onClick = {
                                practiceCorrectCount = 0
                                practiceTotalCount = 0
                                isPracticeFinished = false
                                CurrLesson = 2
                            },
                            enabled = learnedWords.isNotEmpty(),
                            interactionSource = practiceInteraction,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .padding(top = 16.dp)
                                .bouncy(practiceInteraction)
                        ) {
                            Text("Practice Words")
                        }

                        val learnInteraction = remember { MutableInteractionSource() }
                        Button(
                            onClick = {
                                val nextWord = CourseData.words.find { it.term !in learnedWords }
                                if (nextWord != null) {
                                    showNewWordDialog = nextWord
                                    scope.launch {
                                        context.dataStore.edit { prefs ->
                                            val current = prefs[LearnedWordsKEY] ?: emptySet()
                                            prefs[LearnedWordsKEY] = current + nextWord.term
                                        }
                                    }
                                }
                            },
                            enabled = learnedWords.size < CourseData.words.size,
                            interactionSource = learnInteraction,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                                .bouncy(learnInteraction)
                        ) {
                            Text(if (learnedWords.size < CourseData.words.size) "Learn New Word" else "All Words Learned!")
                        }
                        
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                        
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val learnedList = CourseData.words.filter { it.term in learnedWords }
                            items(learnedList.size) { i ->
                                val word = learnedList[i]
                                WordCard(word = word) {
                                    CurrPhrase = CourseData.words.indexOf(word)
                                    CurrLesson = 1
                                }
                            }
                        }
                    }
                }

                if (item == 3 && lesson == 0) {
                    var showResetDialog by remember { mutableStateOf(false) }
                    val themeMode by remember { context.dataStore.data.map { it[ThemeModeKEY] ?: 0 } }.collectAsState(initial = 0)

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Theme Settings",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        
                        val radioOptions = listOf("System Default", "Light", "Dark")
                        Column(Modifier.selectableGroup()) {
                            radioOptions.forEachIndexed { index, text ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .height(56.dp)
                                        .bouncyClickable {
                                            scope.launch {
                                                context.dataStore.edit { it[ThemeModeKEY] = index }
                                            }
                                        }
                                        .padding(horizontal = 16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = (index == themeMode),
                                        onClick = null
                                    )
                                    Text(
                                        text = text,
                                        style = MaterialTheme.typography.bodyLarge,
                                        modifier = Modifier.padding(start = 16.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(32.dp))
                        
                        val resetInteraction = remember { MutableInteractionSource() }
                        Button(
                            onClick = { showResetDialog = true },
                            interactionSource = resetInteraction,
                            modifier = Modifier.fillMaxWidth().bouncy(resetInteraction),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                        ) {
                            Text("Reset App Progress", color = Color.White)
                        }

                        if (showResetDialog) {
                            AlertDialog(
                                onDismissRequest = { showResetDialog = false },
                                title = { Text("Reset Progress") },
                                text = { Text("Are you sure you want to reset all your course progress and scores? This action cannot be undone.") },
                                confirmButton = {
                                    val confirmInteraction = remember { MutableInteractionSource() }
                                    TextButton(
                                        onClick = {
                                            scope.launch {
                                                context.dataStore.edit { it.clear() }
                                                showResetDialog = false
                                                selectedItem = 1 
                                            }
                                        },
                                        interactionSource = confirmInteraction,
                                        modifier = Modifier.bouncy(confirmInteraction)
                                    ) {
                                        Text("Reset", color = Color.Red)
                                    }
                                },
                                dismissButton = {
                                    val dismissInteraction = remember { MutableInteractionSource() }
                                    TextButton(
                                        onClick = { showResetDialog = false },
                                        interactionSource = dismissInteraction,
                                        modifier = Modifier.bouncy(dismissInteraction)
                                    ) {
                                        Text("Cancel")
                                    }
                                }
                            )
                        }
                    }
                }

                if (item == 1 && lesson == 1) {
                    val currentCourse = courses.getOrNull(CurrPhrase)
                    if (currentCourse != null) {
                        val questions = currentCourse.questions
                        val options = currentCourse.options
                        val correctAnswers = currentCourse.correctAnswers
                        val shuffledOptions = remember(currentCourse) {
                            options.map { it.withIndex().shuffled() }
                        }

                        if (quizFinished) {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                item {
                                    Text(
                                        text = "Quiz Finished!",
                                        modifier = Modifier.padding(20.dp),
                                        style = MaterialTheme.typography.headlineMedium
                                    )
                                    var score = 0
                                    questions.forEachIndexed { index, _ ->
                                        val userAnswer = userAnswers[index]
                                        val correctAnswer = correctAnswers.getOrNull(index)
                                        if (userAnswer == correctAnswer) score++
                                    }
                                    
                                    LaunchedEffect(Unit) {
                                        context.dataStore.edit { preferences ->
                                            val currentScore = preferences[intPreferencesKey("score_$CurrPhrase")] ?: -1
                                            if (score > currentScore) {
                                                preferences[intPreferencesKey("score_$CurrPhrase")] = score
                                            }
                                            val finishedCount = preferences[PhrasesCompleteKEY] ?: 0
                                            if (CurrPhrase >= finishedCount) {
                                                preferences[PhrasesCompleteKEY] = CurrPhrase + 1
                                            }
                                        }
                                    }

                                    questions.forEachIndexed { index, question ->
                                        val userAnswer = userAnswers[index]
                                        val correctAnswer = correctAnswers.getOrNull(index)
                                        val isCorrect = userAnswer == correctAnswer
                                        val currentQuestionOptions = options.getOrNull(index) ?: emptyList()

                                        Card(
                                            modifier = Modifier
                                                .padding(10.dp)
                                                .fillMaxWidth(),
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isCorrect) Color.Green.copy(alpha = 0.1f) else Color.Red.copy(alpha = 0.1f)
                                            )
                                        ) {
                                            Column(modifier = Modifier.padding(15.dp)) {
                                                Text(text = "Q: $question", fontWeight = FontWeight.Bold)
                                                Text(
                                                    text = "Your answer: ${if (userAnswer != null) currentQuestionOptions.getOrElse(userAnswer) { "Unknown" } else "Not answered"}",
                                                    color = if (isCorrect) Color.DarkGray else Color.Red
                                                )
                                                if (!isCorrect) {
                                                    Text(
                                                        text = "Correct answer: ${if (correctAnswer != null) currentQuestionOptions.getOrElse(correctAnswer) { "Unknown" } else "N/A"}",
                                                        color = Color(0xFF0D6DC0)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    Text(
                                        text = "Score: $score / ${questions.size}",
                                        style = MaterialTheme.typography.headlineSmall,
                                        modifier = Modifier.padding(20.dp)
                                    )
                                    val backToCoursesInteraction = remember { MutableInteractionSource() }
                                    Button(
                                        onClick = {
                                            CurrLesson = 0
                                            quizFinished = false
                                        },
                                        interactionSource = backToCoursesInteraction,
                                        modifier = Modifier.padding(20.dp).bouncy(backToCoursesInteraction)
                                    ) {
                                        Text("Back to Courses")
                                    }
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                item {
                                    Card(
                                        modifier = Modifier
                                            .padding(10.dp)
                                            .fillMaxWidth(),
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.1f)
                                        )
                                    ) {
                                        Column(modifier = Modifier.padding(15.dp)) {
                                            Text(
                                                text = "Lesson Context",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Spacer(modifier = Modifier.height(5.dp))
                                            MarkdownText(text = currentCourse.info)
                                        }
                                    }

                                    Text(
                                        text = "Question ${currQuestionIndex + 1} of ${questions.size}",
                                        modifier = Modifier.padding(10.dp)
                                    )
                                    
                                    AnimatedContent(
                                        targetState = currQuestionIndex,
                                        transitionSpec = {
                                            if (targetState > initialState) {
                                                (slideInHorizontally { it } + fadeIn()).togetherWith(slideOutHorizontally { -it } + fadeOut())
                                            } else {
                                                (slideInHorizontally { -it } + fadeIn()).togetherWith(slideOutHorizontally { it } + fadeOut())
                                            }.using(SizeTransform(clip = false))
                                        },
                                        label = "QuestionTransition"
                                    ) { targetIndex ->
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Card(
                                                modifier = Modifier
                                                    .padding(10.dp)
                                                    .fillMaxWidth()
                                            ) {
                                                Text(
                                                    text = questions.getOrElse(targetIndex) { "No Question" },
                                                    modifier = Modifier.padding(20.dp),
                                                    style = MaterialTheme.typography.bodyLarge
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(10.dp))

                                            val currentQuestionShuffledOptions = shuffledOptions.getOrNull(targetIndex) ?: emptyList()
                                            currentQuestionShuffledOptions.forEach { indexedOption ->
                                                val originalIndex = indexedOption.index
                                                val option = indexedOption.value
                                                val isSelected = userAnswers[targetIndex] == originalIndex
                                                Card(
                                                    modifier = Modifier
                                                        .padding(horizontal = 10.dp, vertical = 5.dp)
                                                        .fillMaxWidth()
                                                        .bouncyClickable {
                                                            userAnswers = userAnswers.toMutableMap().apply {
                                                                put(targetIndex, originalIndex)
                                                            }
                                                        },
                                                    colors = CardDefaults.cardColors(
                                                        containerColor = if (isSelected)
                                                            MaterialTheme.colorScheme.primaryContainer
                                                        else
                                                            MaterialTheme.colorScheme.surface
                                                    ),
                                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
                                                ) {
                                                    Text(
                                                        text = option,
                                                        modifier = Modifier.padding(15.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceEvenly
                                    ) {
                                        val prevInteraction = remember { MutableInteractionSource() }
                                        Button(
                                            onClick = {
                                                if (currQuestionIndex > 0) currQuestionIndex--
                                            },
                                            enabled = currQuestionIndex > 0,
                                            interactionSource = prevInteraction,
                                            modifier = Modifier.bouncy(prevInteraction)
                                        ) {
                                            Text("Previous")
                                        }
                                        val nextInteraction = remember { MutableInteractionSource() }
                                        if (currQuestionIndex < questions.size - 1) {
                                            Button(
                                                onClick = {
                                                    currQuestionIndex++
                                                },
                                                interactionSource = nextInteraction,
                                                modifier = Modifier.bouncy(nextInteraction)
                                            ) {
                                                Text("Next")
                                            }
                                        } else {
                                            Button(
                                                onClick = {
                                                    quizFinished = true
                                                },
                                                interactionSource = nextInteraction,
                                                modifier = Modifier.bouncy(nextInteraction)
                                            ) {
                                                Text("Finish")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (item == 2 && lesson == 1) {
                    val word = CourseData.words.getOrNull(CurrPhrase)
                    if (word != null) {
                        WordOverview(word = word)
                    }
                }

                if (item == 2 && lesson == 2) {
                    if (isPracticeFinished) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("Practice Session Ended", style = MaterialTheme.typography.headlineMedium)
                            Spacer(modifier = Modifier.height(16.dp))
                            val percentage = if (practiceTotalCount > 0) (practiceCorrectCount.toFloat() / practiceTotalCount * 100).toInt() else 0
                            Text("Score: $practiceCorrectCount / $practiceTotalCount ($percentage%)", style = MaterialTheme.typography.titleLarge)
                            
                            Spacer(modifier = Modifier.height(32.dp))
                            
                            val learnNextInteraction = remember { MutableInteractionSource() }
                            Button(
                                onClick = {
                                    val nextWord = CourseData.words.find { it.term !in learnedWords }
                                    if (nextWord != null) {
                                        showNewWordDialog = nextWord
                                        scope.launch {
                                            context.dataStore.edit { prefs ->
                                                val current = prefs[LearnedWordsKEY] ?: emptySet()
                                                prefs[LearnedWordsKEY] = current + nextWord.term
                                            }
                                        }
                                        CurrLesson = 0
                                        isPracticeFinished = false
                                    } else {
                                        CurrLesson = 0
                                        isPracticeFinished = false
                                    }
                                },
                                enabled = learnedWords.size < CourseData.words.size,
                                interactionSource = learnNextInteraction,
                                modifier = Modifier.fillMaxWidth().bouncy(learnNextInteraction)
                            ) {
                                Text("Learn a New Word")
                            }
                            
                            val backToWordsInteraction = remember { MutableInteractionSource() }
                            TextButton(
                                onClick = { 
                                    CurrLesson = 0 
                                    isPracticeFinished = false
                                },
                                interactionSource = backToWordsInteraction,
                                modifier = Modifier.padding(top = 8.dp).bouncy(backToWordsInteraction)
                            ) {
                                Text("Back to Vocabulary List")
                            }
                        }
                    } else {
                        WordPracticeScreen(learnedWords = learnedWords)
                    }
                }
            }
        }
    }

    if (showNewWordDialog != null) {
        AlertDialog(
            onDismissRequest = { showNewWordDialog = null },
            title = { Text("New Word Learned!") },
            text = {
                Column {
                    Text(
                        text = showNewWordDialog!!.term,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Definition:", fontWeight = FontWeight.Bold)
                    Text(text = showNewWordDialog!!.definition)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Example:", fontWeight = FontWeight.Bold)
                    Text(
                        text = showNewWordDialog!!.example,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }
            },
            confirmButton = {
                val okInteraction = remember { MutableInteractionSource() }
                TextButton(
                    onClick = { showNewWordDialog = null },
                    interactionSource = okInteraction,
                    modifier = Modifier.bouncy(okInteraction)
                ) {
                    Text("Got it!")
                }
            }
        )
    }
}

@Composable
fun WordPracticeScreen(learnedWords: Set<String>) {
    val words = remember(learnedWords) { CourseData.words.filter { it.term in learnedWords }.shuffled() }
    if (words.isEmpty()) return

    var currentIndex by remember { mutableIntStateOf(0) }
    var showHint by remember { mutableStateOf(false) }
    var selectedOption by remember { mutableIntStateOf(-1) }
    var isAnswered by remember { mutableStateOf(false) }
    
    val currentWord = words[currentIndex % words.size]
    val shuffledOptions = remember(currentWord) { currentWord.practiceOptions.withIndex().shuffled() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Question",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = currentWord.practiceQuestion,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Hint Dropdown
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .bouncyClickable { showHint = !showHint },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (showHint) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Hint", style = MaterialTheme.typography.labelLarge)
            }
        }
            
        AnimatedVisibility(visible = showHint) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Text(
                    text = currentWord.definition,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        shuffledOptions.forEach { (originalIndex, optionText) ->
            val isCorrect = originalIndex == currentWord.correctOptionIndex
            val isSelected = selectedOption == originalIndex
            
            val backgroundColor = when {
                isAnswered && isCorrect -> MaterialTheme.colorScheme.primaryContainer
                isAnswered && isSelected -> MaterialTheme.colorScheme.errorContainer
                else -> MaterialTheme.colorScheme.surface
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .bouncyClickable(enabled = !isAnswered) {
                        selectedOption = originalIndex
                        isAnswered = true
                        if (isCorrect) {
                            practiceCorrectCount++
                        }
                        practiceTotalCount++
                    },
                colors = CardDefaults.cardColors(containerColor = backgroundColor),
                border = androidx.compose.foundation.BorderStroke(
                    width = 2.dp,
                    color = if (isAnswered && isCorrect) MaterialTheme.colorScheme.primary else if (isAnswered && isSelected) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline
                )
            ) {
                Text(
                    text = optionText,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }

        if (isAnswered) {
            val nextInteraction = remember { MutableInteractionSource() }
            Button(
                onClick = {
                    currentIndex++
                    isAnswered = false
                    selectedOption = -1
                    showHint = false
                },
                interactionSource = nextInteraction,
                modifier = Modifier.padding(top = 24.dp).bouncy(nextInteraction)
            ) {
                Text("Next Word")
            }
        }
    }
}

@Composable
fun WordOverview(word: Word) {
    var selectedOption by remember { mutableIntStateOf(-1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Definition",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(text = word.definition, style = MaterialTheme.typography.bodyLarge)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Example",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = word.example,
                    style = MaterialTheme.typography.bodyMedium,
                    fontStyle = FontStyle.Italic
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Practice Question",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = word.practiceQuestion, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(16.dp))

        word.practiceOptions.forEachIndexed { index, option ->
            val isCorrect = index == word.correctOptionIndex
            val isSelected = selectedOption == index

            val backgroundColor = when {
                isSelected && isCorrect -> MaterialTheme.colorScheme.primaryContainer
                isSelected && !isCorrect -> MaterialTheme.colorScheme.errorContainer
                else -> MaterialTheme.colorScheme.surface
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .bouncyClickable { selectedOption = index },
                colors = CardDefaults.cardColors(containerColor = backgroundColor),
                border = androidx.compose.foundation.BorderStroke(2.dp, if (isSelected) (if (isCorrect) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) else MaterialTheme.colorScheme.outline)
            ) {
                Text(
                    text = option,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}

@Composable
fun WordCard(word: Word, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .padding(10.dp)
            .fillMaxWidth()
            .bouncyClickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = word.term,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = word.definition,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Default.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
fun MarkdownText(text: String, modifier: Modifier = Modifier) {
    val annotatedString = buildAnnotatedString {
        val boldRegex = Regex("""\*\*([^*]+)\*\*""")
        var lastIndex = 0
        boldRegex.findAll(text).forEach { matchResult ->
            append(text.substring(lastIndex, matchResult.range.first))
            withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                append(matchResult.groupValues[1])
            }
            lastIndex = matchResult.range.last + 1
        }
        append(text.substring(lastIndex))
    }
    Text(text = annotatedString, modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun DrawMainPreview() {
    LearnEngTheme {
        DrawMain()
    }
}
