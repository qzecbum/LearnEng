package com.prathik.learneng.ui.theme

import androidx.compose.ui.graphics.Color

val Green80 = Color(0xFFB2FF59)
val GreenGrey80 = Color(0xFFC5E1A5)
val LightGreen80 = Color(0xFFDCEDC8)

val Green40 = Color(0xFF388E3C)
val GreenGrey40 = Color(0xFF558B2F)
val LightGreen40 = Color(0xFF689F38)

val DarkGreenBackground = Color(0xFF0D1B0D)
val LightGreenBackground = Color(0xFFF1FDF1)
val DarkGreenSurface = Color(0xFF142914)
val LightGreenSurface = Color(0xFFE9F5E9)

val DarkGreenSurfaceVariant = Color(0xFF1E331E)
val LightGreenSurfaceVariant = Color(0xFFD8E6D8)

val DarkGreenPrimaryContainer = Color(0xFF234B23)
val LightGreenPrimaryContainer = Color(0xFFC8E6C9)
val DarkGreenSecondaryContainer = Color(0xFF2E452E)
val LightGreenSecondaryContainer = Color(0xFFDCEDC8)
